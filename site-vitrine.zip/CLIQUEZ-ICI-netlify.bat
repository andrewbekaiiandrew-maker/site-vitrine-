@echo off
echo ========================================
echo  NETLIFY - DEPLOIEMENT
echo ========================================
echo.
echo Ouvrez ce lien dans votre navigateur :
echo https://app.netlify.com/authorize?response_type=ticket^&ticket=d1f47d1cff4e21b35a5ce197d80fc8d2
echo.
echo Puis revenez ici et appuyez sur une touche...
echo.
echo.
powershell -NoExit -ExecutionPolicy Bypass -Command "node C:\Users\Andrew\AppData\Roaming\npm\node_modules\netlify-cli\bin\run.js login --check d1f47d1cff4e21b35a5ce197d80fc8d2; node C:\Users\Andrew\AppData\Roaming\npm\node_modules\netlify-cli\bin\run.js deploy --dir C:\Users\Andrew\Documents\projets\site-vitrine --prod"
echo.
echo TERMINE ! Votre site est en ligne.
echo.
pause
